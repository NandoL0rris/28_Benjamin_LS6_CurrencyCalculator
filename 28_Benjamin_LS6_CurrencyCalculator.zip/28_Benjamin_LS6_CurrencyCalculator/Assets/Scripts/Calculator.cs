﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class Calculator : MonoBehaviour
{
    public InputField inputConvert;
    public InputField ConvertedValue;
    public float amount;
    public Toggle USDollar;
    public Toggle JPYen;
    public float SGDUSD = 0.74f;
    public float SGDJPY = 82.74f;

    // Start is called before the first frame update
    void Start()
    {
        
        USDollar.isOn = false;
        JPYen.isOn = false;
       
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void Conversion()
    {
        float amount = float.Parse(inputConvert.text);

        if (USDollar.isOn == true)
        {
            JPYen.isOn = false;

            ConvertedValue.text = "$ " + (amount * SGDUSD);
        }
        else if (JPYen.isOn == true)
        {
            USDollar.isOn = false;

            ConvertedValue.text = "¥ " + (amount * SGDJPY);
        }
    }

    public void Clear()
    {
        USDollar.isOn = false;
        JPYen.isOn = false;

        inputConvert.text = " ";
        ConvertedValue.text = " ";
    }




}
